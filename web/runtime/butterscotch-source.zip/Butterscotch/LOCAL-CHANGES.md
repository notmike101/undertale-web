# Local modification notice — 2026-10-17

Based on ButterscotchRunner/Butterscotch revision `f6f1d30a2f933e5e0e77941251c7bd38e361a2ce`.

`src/backends/web.c` adds a character event type, an `onCharacter(unsigned int)` entry point, and delivery to the existing `RunnerKeyboard_onCharacter` implementation through the frame input queue. `CMakeLists.txt` adds `_onCharacter` to the Emscripten exports. This restores browser text entry through `keyboard_lastchar` and `keyboard_string`. No other runtime behavior was changed.

Built on Windows with Emscripten 6.0.12, CMake 4.4.4, Ninja 1.13.2, and Emscripten SDK Python 3.13.3 / Node 24.19.0:

```sh
emcmake cmake -B build -G Ninja -DPLATFORM=web -DBACKEND=web -DCMAKE_BUILD_TYPE=Release -DCMAKE_INTERPROCEDURAL_OPTIMIZATION=ON
cmake --build build --parallel 8
```

The complete upstream source and dependency license notices remain in this archive. See LICENSE for GNU AGPL v3 terms.
